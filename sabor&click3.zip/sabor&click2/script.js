// Array inicial com produtos padrão
let pratos = [
    { id: 1, nome: "X-Burguer Artesanal", categoria: "Lanches", preco: 32.90, desc: "Blend 180g, queijo cheddar fundido e bacon no brioche.", img: "https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=400" },
    { id: 2, nome: "Pizza Margherita G", categoria: "Pizzas", preco: 54.00, desc: "Molho de tomate artesanal, muçarela de búfala e manjericão.", img: "https://images.unsplash.com/photo-1604382354936-07c5d9983bd3?w=400" },
    { id: 3, nome: "Açaí Especial 500ml", categoria: "Sobremesas", preco: 24.50, desc: "Açaí puro batido com granola artesanal e banana.", img: "https://images.unsplash.com/photo-1590301157890-4810ed352733?w=400" }
];

const pratosSalvos = JSON.parse(localStorage.getItem('pratos_sabor_clic'));
if (pratosSalvos && pratosSalvos.length > 0) { pratos = pratosSalvos; }

let carrinho = JSON.parse(localStorage.getItem('carrinho_saborclic')) || [];

// Gestão de Pedidos (KDS)
let pedidos = JSON.parse(localStorage.getItem('pedidos_saborclic')) || [
    { id: 1041, itens: ["X-Burguer Artesanal (x2)"], status: "Aguardando", cliente: "João Silva" },
    { id: 1042, itens: ["Pizza Margherita G (x1)", "Açaí Especial (x1)"], status: "Em Preparo", cliente: "Maria Oliveira" }
];

// Gestão de Usuários (Admin)
let usuarios = JSON.parse(localStorage.getItem('usuarios_saborclic')) || [
    { id: 1, nome: "Carlos Admin", email: "admin@saborclic.com", cargo: "Administrador" },
    { id: 2, nome: "Ana Cozinheira", email: "cozinha@saborclic.com", cargo: "Cozinheiro" },
    { id: 3, nome: "Pedro Cliente", email: "cliente@saborclic.com", cargo: "Cliente" }
];

function atualizarContadorCarrinho() {
    const contador = document.getElementById('cart-count');
    if (contador) contador.textContent = carrinho.reduce((total, item) => total + item.quantidade, 0);
}

function adicionarAoCarrinho(id, nome, preco) {
    const itemExistente = carrinho.find(item => item.id === id);
    if (itemExistente) {
        itemExistente.quantidade += 1;
    } else {
        carrinho.push({ id, nome, preco, quantidade: 1 });
    }
    localStorage.setItem('carrinho_saborclic', JSON.stringify(carrinho));
    atualizarContadorCarrinho();
    alert(nome + " foi adicionado ao carrinho!");
}

function renderCardapio() {
    const menuGrid = document.getElementById('menu-grid');
    if (!menuGrid) return;
    menuGrid.innerHTML = pratos.map(prato => `
        <div class="card">
            <div class="card-img-container"><img src="${prato.img}" alt="${prato.nome}"></div>
            <div class="card-body">
                <h3>${prato.nome}</h3>
                <p>${prato.desc}</p>
                <div class="card-footer">
                    <span class="price">R$ ${prato.preco.toFixed(2).replace('.', ',')}</span>
                    <button class="btn-add" onclick="adicionarAoCarrinho(${prato.id}, '${prato.nome}', ${prato.preco})">Adicionar</button>
                </div>
            </div>
        </div>
    `).join('');
}

function renderCarrinhoPagina() {
    const container = document.getElementById('cart-items-page');
    const totalEl = document.getElementById('cart-total-price');
    if (!container || !totalEl) return;

    if (carrinho.length === 0) {
        container.innerHTML = '<p style="color: #666; text-align: center; padding: 20px;">O seu carrinho está vazio.</p>';
        totalEl.textContent = 'R$ 0,00';
        return;
    }

    let precoTotal = 0;
    container.innerHTML = carrinho.map((item, index) => {
        const subtotal = item.preco * item.quantidade;
        precoTotal += subtotal;
        return `
            <div style="display: flex; justify-content: space-between; align-items: center; padding: 12px 0; border-bottom: 1px solid #eee;">
                <div>
                    <h4 style="font-size: 15px; color: #232323;">${item.nome}</h4>
                    <p style="font-size: 13px; color: #666;">R$ ${item.preco.toFixed(2).replace('.', ',')} x ${item.quantidade}</p>
                </div>
                <div style="display: flex; align-items: center; gap: 15px;">
                    <span style="font-weight: 600; color: #F06C2D;">R$ ${subtotal.toFixed(2).replace('.', ',')}</span>
                    <button onclick="removerItemCarrinho(${index})" style="background: #ff4d4d; color: white; border: none; padding: 5px 10px; border-radius: 6px; cursor: pointer; font-size: 12px;">Remover</button>
                </div>
            </div>
        `;
    }).join('');
    totalEl.textContent = `R$ ${precoTotal.toFixed(2).replace('.', ',')}`;
}

function removerItemCarrinho(index) {
    carrinho.splice(index, 1);
    localStorage.setItem('carrinho_saborclic', JSON.stringify(carrinho));
    atualizarContadorCarrinho();
    renderCarrinhoPagina();
}

function finalizarPedido() {
    if (carrinho.length === 0) {
        alert("Seu carrinho está vazio!");
        return;
    }
    const novoPedido = {
        id: Math.floor(1000 + Math.random() * 9000),
        itens: carrinho.map(i => `${i.nome} (x${i.quantidade})`),
        status: "Aguardando",
        cliente: "Cliente Atual"
    };
    pedidos.push(novoPedido);
    localStorage.setItem('pedidos_saborclic', JSON.stringify(pedidos));

    alert("Pedido finalizado com sucesso!");
    carrinho = [];
    localStorage.removeItem('carrinho_saborclic');
    window.location.href = 'rastreamento.html';
}

function renderCozinhaPedidos() {
    const kdsContainer = document.getElementById('kds-pedidos-grid');
    if (!kdsContainer) return;

    if (pedidos.length === 0) {
        kdsContainer.innerHTML = '<p style="color: #666;">Nenhum pedido na fila no momento.</p>';
        return;
    }

    kdsContainer.innerHTML = pedidos.map((pedido, index) => `
        <div class="page-card" style="border-left: 5px solid #F06C2D; margin-bottom: 15px;">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px;">
                <h3 style="font-size: 18px;">Pedido #${pedido.id}</h3>
                <span style="padding: 4px 10px; border-radius: 6px; font-size: 12px; font-weight: 600; background: ${pedido.status === 'Pronto' ? '#d4edda' : pedido.status === 'Em Preparo' ? '#fff3cd' : '#f8d7da'}; color: ${pedido.status === 'Pronto' ? '#155724' : pedido.status === 'Em Preparo' ? '#856404' : '#721c24'};">
                    ${pedido.status}
                </span>
            </div>
            <p style="font-size: 13px; color: #666; margin-bottom: 10px;">Cliente: <b>${pedido.cliente}</b></p>
            <ul style="margin-left: 20px; font-size: 14px; color: #444; margin-bottom: 15px;">
                ${pedido.itens.map(item => `<li>${item}</li>`).join('')}
            </ul>
            <div style="display: flex; gap: 10px;">
                <button onclick="mudarStatusPedido(${index}, 'Aguardando')" style="background: #f8d7da; border: none; padding: 6px 12px; border-radius: 6px; cursor: pointer; font-size: 12px; font-weight: 600;">Aguardando</button>
                <button onclick="mudarStatusPedido(${index}, 'Em Preparo')" style="background: #fff3cd; border: none; padding: 6px 12px; border-radius: 6px; cursor: pointer; font-size: 12px; font-weight: 600;">Em Preparo</button>
                <button onclick="mudarStatusPedido(${index}, 'Pronto')" style="background: #d4edda; border: none; padding: 6px 12px; border-radius: 6px; cursor: pointer; font-size: 12px; font-weight: 600;">Pronto</button>
            </div>
        </div>
    `).join('');
}

function mudarStatusPedido(index, novoStatus) {
    pedidos[index].status = novoStatus;
    localStorage.setItem('pedidos_saborclic', JSON.stringify(pedidos));
    renderCozinhaPedidos();
}

function cadastrarUsuario(event) {
    event.preventDefault();
    const nome = document.getElementById('nome-usuario').value;
    const email = document.getElementById('email-usuario').value;
    const cargo = document.getElementById('cargo-usuario').value;

    const novoUsuario = { id: Date.now(), nome, email, cargo };
    usuarios.push(novoUsuario);
    localStorage.setItem('usuarios_saborclic', JSON.stringify(usuarios));

    alert("Usuário cadastrado com sucesso!");
    document.getElementById('form-usuario').reset();
    renderUsuariosLista();
}

function renderUsuariosLista() {
    const listaEl = document.getElementById('admin-usuarios-lista');
    if (!listaEl) return;

    listaEl.innerHTML = usuarios.map((user, index) => `
        <div style="display: flex; justify-content: space-between; align-items: center; padding: 12px 0; border-bottom: 1px solid #eee;">
            <div>
                <h4 style="font-size: 15px; color: #232323;">${user.nome} <span style="font-size: 11px; background: #FFF8EB; color: #F06C2D; padding: 2px 6px; border-radius: 4px; border: 1px solid #F06C2D;">${user.cargo}</span></h4>
                <p style="font-size: 13px; color: #666;">${user.email}</p>
            </div>
            <button onclick="removerUsuario(${index})" style="background: #ff4d4d; color: white; border: none; padding: 6px 12px; border-radius: 6px; cursor: pointer; font-size: 12px;">Remover</button>
        </div>
    `).join('');
}

function removerUsuario(index) {
    usuarios.splice(index, 1);
    localStorage.setItem('usuarios_saborclic', JSON.stringify(usuarios));
    renderUsuariosLista();
}

function cadastrarPrato(event) {
    event.preventDefault();
    
    const idEditando = document.getElementById('id-prato-editando').value;
    const nome = document.getElementById('nome-prato').value;
    const categoria = document.getElementById('cat-prato').value;
    const preco = parseFloat(document.getElementById('preco-prato').value);
    const desc = document.getElementById('desc-prato').value;

    if (idEditando) {
        const prato = pratos.find(p => p.id == idEditando);
        if (prato) {
            prato.nome = nome;
            prato.categoria = categoria;
            prato.preco = preco;
            prato.desc = desc;
        }
        alert("Prato atualizado com sucesso!");
        document.getElementById('id-prato-editando').value = '';
        document.getElementById('btn-salvar-prato').textContent = 'Cadastrar Prato';
    } else {
        const novoPrato = {
            id: Date.now(),
            nome,
            categoria,
            preco,
            desc,
            img: "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=400"
        };
        pratos.push(novoPrato);
        alert("Prato cadastrado com sucesso!");
    }

    localStorage.setItem('pratos_sabor_clic', JSON.stringify(pratos));
    document.getElementById('form-prato').reset();
    renderAdminMenu();
    renderCardapio();
}

function renderAdminMenu() {
    const listEl = document.getElementById('admin-menu-list');
    if (!listEl) return;

    if (pratos.length === 0) {
        listEl.innerHTML = '<p style="color: #666; text-align: center; padding: 15px;">Nenhum prato cadastrado.</p>';
        return;
    }

    listEl.innerHTML = pratos.map(prato => `
        <div style="display: flex; justify-content: space-between; align-items: center; padding: 12px 0; border-bottom: 1px solid #eee;">
            <div>
                <h4 style="font-size: 15px; color: #232323;">${prato.nome} <span style="font-size: 11px; background: #FFF8EB; color: #F06C2D; padding: 2px 6px; border-radius: 4px; border: 1px solid #F06C2D;">${prato.categoria}</span></h4>
                <p style="font-size: 13px; color: #666;">R$ ${prato.preco.toFixed(2).replace('.', ',')} - ${prato.desc}</p>
            </div>
            <div style="display: flex; gap: 8px;">
                <button onclick="carregarPratoParaEdicao(${prato.id})" style="background: #ffc107; color: #000; border: none; padding: 6px 12px; border-radius: 6px; cursor: pointer; font-size: 12px; font-weight: 600;">Editar</button>
                <button onclick="removerPratoPorId(${prato.id})" style="background: #ff4d4d; color: white; border: none; padding: 6px 12px; border-radius: 6px; cursor: pointer; font-size: 12px; font-weight: 600;">Excluir</button>
            </div>
        </div>
    `).join('');
}

function carregarPratoParaEdicao(id) {
    const prato = pratos.find(p => p.id == id);
    if (!prato) return;

    document.getElementById('id-prato-editando').value = prato.id;
    document.getElementById('nome-prato').value = prato.nome;
    document.getElementById('cat-prato').value = prato.categoria;
    document.getElementById('preco-prato').value = prato.preco;
    document.getElementById('desc-prato').value = prato.desc;
    
    document.getElementById('btn-salvar-prato').textContent = 'Salvar Alterações';
    window.scrollTo({ top: 0, behavior: 'smooth' });
}

function removerPratoPorId(id) {
    if (confirm("Tem certeza que deseja excluir este prato?")) {
        pratos = pratos.filter(p => p.id != id);
        localStorage.setItem('pratos_sabor_clic', JSON.stringify(pratos));
        renderAdminMenu();
        renderCardapio();
    }
}

function alternarAltoContraste() {
    document.body.classList.toggle('high-contrast');
    const ativo = document.body.classList.contains('high-contrast');
    localStorage.setItem('altocontraste_saborclic', ativo ? 'sim' : 'nao');
}

document.addEventListener('DOMContentLoaded', () => {
    if (localStorage.getItem('altocontraste_saborclic') === 'sim') {
        document.body.classList.add('high-contrast');
    }
    atualizarContadorCarrinho();
    renderCardapio();
    renderCarrinhoPagina();
    renderCozinhaPedidos();
    renderUsuariosLista();
});